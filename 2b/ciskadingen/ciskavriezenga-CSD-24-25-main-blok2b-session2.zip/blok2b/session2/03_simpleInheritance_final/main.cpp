#include "dog.h"
#include "cat.h"

int main ()
{
  Cat aCat("Foo");
  Dog aDog("Bar");

  // end program
  return 0;
}
