# Oscillator

1. Oscillator class with an empty constructor and destructor
2. Add the field 'freq' as a public field, illustrate that we can change its value. 
3. Make field freq private --> we are not allowed to alter the freq field.
4. Add setter & getter and use these.
5. Add constructor
6. Add constructor delegation
7. Add initializer list