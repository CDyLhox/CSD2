#include <iostream>

class Woofer
{
public:
  int impedance;
  float coilPosition;
  void move(float coilPosition);
};


