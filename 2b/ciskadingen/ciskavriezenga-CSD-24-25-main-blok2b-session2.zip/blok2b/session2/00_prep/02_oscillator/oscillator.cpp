#include "oscillator.h"

Oscillator::Oscillator()
{
    std::cout << "Inside Oscillator constructor\n";
}

Oscillator::~Oscillator()
{
  std::cout << "Inside Oscillator destructor\n";
}
