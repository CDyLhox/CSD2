# EINDOPDRACHT!

<br>Ook weer: **KISS!** 
- Ga eerst uit van twee hele eenvoudige synthesizers, bijv. 
  - Additive synth - die boventonen stapelt adhv meegegeven aantal  
  - Organ Synth - met twee blokgolven met kwint (+ slightly off tune? --> zweving :D) uit elkaar 



Tips: 
- Gebruik in je Synth base- en derived classes op dezelfde wijze functies als in de Oscillator base en derived classes de tick en calculate methods.
- Voeg aan je Synth base class de fields ```sample, amplitude``` toe.

