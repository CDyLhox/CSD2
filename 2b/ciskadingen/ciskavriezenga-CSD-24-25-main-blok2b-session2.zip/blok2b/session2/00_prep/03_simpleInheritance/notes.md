# Simple inheritance example

1. Show classes, build and run 
2. Discuss 'protected' - change into private and show that Dog and Cat are not allowed to use the field 'name'.
3. Add bark method to dog and illustrate that we can run this for a dog but not for a pet or cat.
4. Add climb method to cat, illustrate - idem. 