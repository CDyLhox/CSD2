
class Tweeter{
public:
  // default constructor
  Tweeter();
  // overloaded constructor
  Tweeter(float diam);

  // TODO - add destructor

  // fields
  float diameter;
  float conePosition;
};
