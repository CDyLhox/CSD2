import time

print("Program begins")

time.sleep(2) # delay in seconds

print("Program ends")

