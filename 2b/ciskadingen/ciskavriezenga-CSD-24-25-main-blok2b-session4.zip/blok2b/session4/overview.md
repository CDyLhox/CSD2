
# Session 4

## Content

* #### 'Stand van zaken'
  * Recap last week
  * Hoe gaat het?
  * git _(* randvoorwaarde)_


* #### (pure) virtual methods & abstract classes
  * 01_override 
  * <b>slides - session 4</b>
  * 02_override --> virtual method
  * 02_override --> pure virtual method & abstract class

* #### oscillators
  03_sineSquareSaw and 04_sineSquareSawFinal
    1. let's add Sine as subclass of Oscillator 
    2. add subclass square
    3. add subclass saw --> assignment

* #### callback 
  Audio callback functionality

* #### class diagram
  Eindopdracht class diagram - eerste start

