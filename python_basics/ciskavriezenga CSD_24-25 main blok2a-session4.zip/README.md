
# Session 4 
## content
* #### 'Stand van zaken'
  * Recap last week - Duration vs. timestamps
  * Hoe gaat het?

* #### Vandaag 
  * Dictionary
  * Events
  * Functions

