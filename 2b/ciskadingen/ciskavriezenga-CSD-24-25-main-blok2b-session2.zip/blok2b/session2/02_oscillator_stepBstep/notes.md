<H1>Content</H1>

<H3>Content session</H3>

* Oscillator class
* access specifiers, public, private and protected
* initialiser list
* constructor Delegation
______
* _Basic inheritance_

<H3>Code examples</H3>

1.  Oscillator class - default constructor, destructor
2.  Oscillator class, with the field frequency, constructor delegation,
      initializer list
3.  Oscillator class, private field frequency, getter and setter, this pointer

<H3>Run code with c++11 / c++14 / c++17 </H3>
To run with c++11 / c++14 / c++17
g++ -std=c++17  oscillator_extended.cpp -o osc
