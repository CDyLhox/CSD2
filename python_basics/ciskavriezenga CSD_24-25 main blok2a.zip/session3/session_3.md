
# Session 3

Content

* #### 'Stand van zaken'
  * Recap last week
  * Hoe gaat het?
  * git _(* randvoorwaarde)_

* #### Opdracht 2 
  * 3a_exercise2.py
  * 3a_excercise2_final.py

* #### Duration vs. timestamps

  m
