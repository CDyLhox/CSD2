#include "oscillator.h"

class Tremelo
{
public:
  //constructor and destructor
  Tremelo();
  ~Tremelo();

private:
  Oscillator oscillator;
};
