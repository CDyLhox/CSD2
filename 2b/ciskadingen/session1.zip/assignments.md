# Session 1 - assignments

### 1 Hello world
Indien nog niet gedaan, schrijf je eigen hello world. 
Start met: "Hello" loggen naar de terminal
Bouw dan je programma uit met bijv. het opvragen van je naam, leeftijd en ...?... en reageer daar op door deze waarden weer te loggen naar de terminal. Zie bijv. het voorbeeld in 1_hello. 

### 2 Instrument opdracht 
Zie blok2b\assignments directory, assignment "instrument_class.pdf"
MAAR: "Project files" --> losse bestanden hoeven nog niet.

### 3 Voeg een Woofer toe aan het speaker voorbeeld
Zie voorbeeld 3_speaker

### 4 Eigen classes
Bedenk zelf een aantal classes en werk deze uit in werkende voorbeelden, waarbij je logt naar de console en om input vraagt. 

### 5 Cmake installeren en testen
Installeer cmake en test het met het voorbeeld  in 4_cmake_test

### 6 EXTRA: Coffeemaker
Zie blok2b\assignments\extra directory, assignment "Coffeemaker.pdf"

### 7 EXTRA 2: Scale
Zie blok2b\assignments\extra directory, assignment "Scale.pdf"



