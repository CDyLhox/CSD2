

#### Square
```
  // calculate square
  if(phase < 0.5) {
    sample = 1.0;
  } else {
    sample = -1.0;
  }
```
#### Saw  
    // calculate saw wave
    sample = phase * 2.0 - 1.0;