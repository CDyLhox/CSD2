#include "oscillator.h"

int main()
{
  std::cout << "\nin main\n";
  Oscillator osc;


  // end program
  return 0;
}
