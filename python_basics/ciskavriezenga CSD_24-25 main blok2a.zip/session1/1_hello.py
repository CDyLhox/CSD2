# hello world in a for loop 
import time

for i in range(1,6):
    print(i, "hello")
    time.sleep(1)
