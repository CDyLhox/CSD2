# Session 2 - assignments

### 1 CMAKE & JUCE WERKEND (als je dat nog niet had)
Zie 
- session1\4_cmake_test
- session2\04_JuceTest

### 2 Saw & Square
- Kopieer de directory sounding sine naar je eigen repo.
- Voeg een saw.h & saw.cpp toe en werk deze uit 
- Voeg een square.h & square.cpp toe en werk deze uit
<br>**NOTE: KISS principe**, gewoon een hele harde saw en square (aliasing dus)

### 3 Oscillator base class
Werk verder in je 2 Saw & Square directory of maak een kopie. 
<br>Welke code is duplicate code? --> plaats dit in een Oscillator base class

### 4 Class diagram opstellen voor eindopdracht 
Neem de eindopdracht door en werk een eerste class diagram uit. 
<br>Ook weer: **KISS!** 
- Ga eerst uit van twee hele eenvoudige synthesizers, bijv. 
  - Additive synth - die boventonen stapelt adhv meegegeven aantal  
  - Organ Synth - met twee blokgolven met kwint (+ slightly off tune? --> zweving :D) uit elkaar 


### 5 OPTIONEEL - Start aan de eindopdracht 
Opdracht 3 is al de start van je eindopdracht ;), kopieer deze en start nu echt je eind project. 