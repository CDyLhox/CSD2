#include "simpleSynth.h"
#include <iostream>

SimpleSynth::SimpleSynth()
{
  std::cout << "\n* SimpleSynth::SimpleSynth - constructor\n";
}

SimpleSynth::~SimpleSynth()
{
  std::cout << "\n* SimpleSynth::~SimpleSynth - destructor\n";
}
