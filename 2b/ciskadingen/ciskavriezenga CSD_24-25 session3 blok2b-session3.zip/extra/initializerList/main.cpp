#include <iostream>
#include "simpleSynth.h"
#include "tremelo.h"


int main()
{
  SimpleSynth simpleSynth;
  Tremelo tremelo;
  // end main
  return 0;
}
