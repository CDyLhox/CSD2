#include "oscillator.h"

class SimpleSynth
{
public:
  //constructor and destructor
  SimpleSynth();
  ~SimpleSynth();

private:
  Oscillator oscillator;
};
