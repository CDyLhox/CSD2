#include "tremelo.h"
#include <iostream>

Tremelo::Tremelo()
{
  std::cout << "\n* Tremelo::Tremelo - constructor\n";
}

Tremelo::~Tremelo()
{
  std::cout << "\n* Tremelo::~Tremelo - destructor\n";
}
